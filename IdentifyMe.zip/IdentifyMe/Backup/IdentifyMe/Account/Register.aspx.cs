﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using UserManagement;
using UserManagement.Models;

namespace IdentifyMe.Account
{
    public partial class Register : System.Web.UI.Page
    {
        public UserManagementService userManagement = new UserManagementService();
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }
        protected void CreateUserButton_Click(object sender, EventArgs e)
        {
            UserInfo userInfo = new UserInfo();
            userInfo.UserName = UserName.Text;
            userInfo.UserType = ddlUserType.SelectedValue.Equals(UserType.Admin) ? UserType.Admin : UserType.General;
            userInfo.FirstName = FirstName.Text;
            userInfo.LastName = LastName.Text;
            userInfo.Mobile = Mobile.Text;
            userInfo.Gender = Gender.SelectedValue.Equals(GenderType.Male) ? GenderType.Male : GenderType.Female;
            userInfo.Address = Address.Text;
            userInfo.Email = Email.Text;
            userInfo.Password = Password.Text;
            userInfo.DOB = DateTime.ParseExact(DOB.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            userManagement.RegisterUser(userInfo);
        }

    }
}
