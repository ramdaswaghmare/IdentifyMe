﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UserManagement;
using UserManagement.Models;

namespace IdentifyMe.Account
{
    public partial class Login : System.Web.UI.Page
    {
        UserManagementService ums = new UserManagementService();

        protected void Page_Load(object sender, EventArgs e)
        {
            RegisterHyperLink.NavigateUrl = "Register.aspx?ReturnUrl=" + HttpUtility.UrlEncode(Request.QueryString["ReturnUrl"]);
        }

        protected void LoginButton_Click(object sender, EventArgs e)
        {
            string username = UserName.Text;
            string password = Password.Text;

            UserInfo User = ums.Login(username, password);

            if (User != null)
            {
                Session["UserInSessionS"] = User;

                if (IsPostBack)
                {
                    LoginView lv = (LoginView)this.Master.Page.FindControl("HeadLoginView");
                    if (lv != null)
                    {
                        LoginName ln = (LoginName)lv.FindControl("HeadLoginName");
                        if (ln != null)
                        {
                            Response.Write("LoginName control found");
                        }
                    }
                }

                Response.Redirect("~/Visitors.aspx");
                               
            }
            else 
            {
                ValidationFailure.Text = "Username or password is incorrect";
                ValidationFailure.Visible = true;
            }
        }
    }
}
