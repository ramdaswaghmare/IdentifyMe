﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IdentifyMe.Models
{
    public class Register
    {
        public String UserName { get; set; }
        public String Eamil { get; set; }
        public String UserType { get; set; }
        public String Password { get; set; }
    }
}