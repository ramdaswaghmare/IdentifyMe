﻿using System;
using UserManagement.Models;
using VisitorManagement;
using VisitorManagement.Models;

namespace IdentifyMe
{
    public partial class Visitors : System.Web.UI.Page
    {
        VisitorManagementService vms = new VisitorManagementService();
        protected void Page_Load(object sender, EventArgs e)
        {
              
        }

        protected void SaveButton_Click(object sender, EventArgs e)
        {
            VisitorDetails vsd = null;

            Visitor visitor = new Visitor();
            IDProofDetails idProof = new IDProofDetails();
            
            visitor.Name = VisitorName.Text;
            visitor.Gender = Gender.SelectedValue.Equals(GenderType.Male) ? GenderType.Male : GenderType.Female;
            visitor.Mobile = Mobile.Text;
            visitor.PersonWantToVisit = PersonToVisit.Text;
            visitor.PerposeOfVisit = PerposeOfVisit.Text;
            visitor.NoOfPersonWith = Convert.ToInt32(NoOfPersonWith.Text);
            visitor.DateTimeIn = DateTime.Now;
            visitor.DateTimeOut = null;
            visitor.IssuedBy = ((UserInfo)Session["UserInSessionS"]).UserId;

            idProof.IdentityProofTypeId = Convert.ToInt32(ddlIdentityProofTypeId.SelectedValue);
            idProof.IdProofNumber = IdProofNumber.Text;


            visitor.VehicleName = VehicleName.Text;
            visitor.VehicleNo = VehicleNo.Text;
         

            vsd = new VisitorDetails();
            vsd.Visitor = visitor;
            vsd.IDProofDetails = idProof;

            vms.AddVisitor(vsd);
        }

        protected void AllVisitors_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/AllVisitors.aspx");
        }
    }
}