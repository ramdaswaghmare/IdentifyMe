﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SQL;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace UserManagement
{
    public class UserManagementService
    {
        public IDatabaseService db = new DatabaseService();

        public void RegisterUser(User UserInfo)
        {
            SqlParameter[] parameters = new SqlParameter[] 
            {
                new SqlParameter("@UserName",SqlDbType.NVarChar),
                new SqlParameter("@UserType",SqlDbType.NVarChar),
                new SqlParameter("@FirstName",SqlDbType.NVarChar),
                new SqlParameter("@LastName",SqlDbType.NVarChar),
                new SqlParameter("@Mobile",SqlDbType.NVarChar),
                new SqlParameter("@Gender",SqlDbType.NVarChar),
                new SqlParameter("@Address",SqlDbType.NVarChar),
                new SqlParameter("@Email",SqlDbType.NVarChar),
                new SqlParameter("@Password",SqlDbType.NVarChar),
                new SqlParameter("@DateOfBirth",SqlDbType.Date)
            };

            parameters[0].Value = UserInfo.UserName;
            parameters[1].Value = UserInfo.UserType;
            parameters[2].Value = UserInfo.FirstName;
            parameters[3].Value = UserInfo.LastName;
            parameters[4].Value = UserInfo.Mobile;
            parameters[5].Value = UserInfo.Gender;
            parameters[6].Value = UserInfo.Address;
            parameters[7].Value = UserInfo.Email;
            parameters[8].Value = UserInfo.Password;
            parameters[9].Value = UserInfo.DOB;

            db.ExecuteNonQuery("SpAddUser", parameters);
            
        }
    }
}
