﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using UserManagement.Models;
using SQL;

namespace UserManagement
{
    public class UserManagementService
    {
        public IDatabaseService db = new DatabaseService();

        public void RegisterUser(UserInfo UserInfo)
        {
            SqlParameter[] parameters = new SqlParameter[] 
            {
                new SqlParameter("@UserName",SqlDbType.NVarChar),
                new SqlParameter("@UserType",SqlDbType.NVarChar),
                new SqlParameter("@FirstName",SqlDbType.NVarChar),
                new SqlParameter("@LastName",SqlDbType.NVarChar),
                new SqlParameter("@Mobile",SqlDbType.NVarChar),
                new SqlParameter("@Gender",SqlDbType.NVarChar),
                new SqlParameter("@Address",SqlDbType.NVarChar),
                new SqlParameter("@Email",SqlDbType.NVarChar),
                new SqlParameter("@Password",SqlDbType.NVarChar),
                new SqlParameter("@DateOfBirth",SqlDbType.Date)
            };

            parameters[0].Value = UserInfo.UserName;
            parameters[1].Value = UserInfo.UserType;
            parameters[2].Value = UserInfo.FirstName;
            parameters[3].Value = UserInfo.LastName;
            parameters[4].Value = UserInfo.Mobile;
            parameters[5].Value = UserInfo.Gender;
            parameters[6].Value = UserInfo.Address;
            parameters[7].Value = UserInfo.Email;
            parameters[8].Value = UserInfo.Password;
            parameters[9].Value = UserInfo.DOB;

            db.ExecuteNonQuery("SpAddUser", parameters);

        }

        public UserInfo Login(string username, string password)
        {
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@username",SqlDbType.NVarChar),
                new SqlParameter("@password",SqlDbType.NVarChar)
            };

            parameters[0].Value = username;
            parameters[1].Value = password;

            SqlDataReader rdr = db.ExecuteReader("prcValidateCredential", parameters);

            return GetUser(rdr);
        }

        private UserInfo GetUser(SqlDataReader rdr)
        {
            UserInfo LoggedInUser = null;

            if (rdr.HasRows)
            {
                LoggedInUser = new UserInfo();
                while (rdr.Read())
                {
                    LoggedInUser.UserId = rdr.GetInt32(rdr.GetOrdinal("UserId"));
                    LoggedInUser.UserName = rdr.GetString(rdr.GetOrdinal("UserName"));
                    LoggedInUser.UserType = rdr.GetString(rdr.GetOrdinal("UserType")).Equals(UserType.Admin) ? UserType.Admin : UserType.General;
                    LoggedInUser.FirstName = rdr.GetString(rdr.GetOrdinal("FirstName"));
                    LoggedInUser.LastName = rdr.GetString(rdr.GetOrdinal("LastName"));
                    LoggedInUser.Mobile = rdr.GetString(rdr.GetOrdinal("Mobile"));
                    LoggedInUser.Gender = rdr.GetString(rdr.GetOrdinal("Gender")).Equals(GenderType.Male) ? GenderType.Male : GenderType.Female;
                    LoggedInUser.DOB = rdr.GetDateTime(rdr.GetOrdinal("DateOfBirth"));
                    LoggedInUser.Address = rdr.GetString(rdr.GetOrdinal("Address"));
                    LoggedInUser.Email = rdr.GetString(rdr.GetOrdinal("Email"));
                }
                return LoggedInUser;
            }
            return LoggedInUser;
        }
    }
}
