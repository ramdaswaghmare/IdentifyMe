﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UserManagement
{
    public enum UserType
    {
        General = 1,
        Admin = 2

    }
}
