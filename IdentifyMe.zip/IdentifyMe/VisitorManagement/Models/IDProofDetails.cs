﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VisitorManagement.Models
{
    public class IDProofDetails
    {
        public int IdentityProofTypeId { get; set; }
        public string IdProofNumber { get; set; }
        public int? VisitorId { get; set; }
    }
}
