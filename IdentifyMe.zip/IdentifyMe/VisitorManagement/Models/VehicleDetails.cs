﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VisitorManagement.Models
{
    public class VehicleDetails
    {
        public int? VehicleTypeID { get; set; }
        public string VehicleNo { get; set; }
        public int? VisitorId { get; set; }
    }
}
