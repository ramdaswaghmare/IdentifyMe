﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UserManagement.Models;

namespace VisitorManagement.Models
{
    public class Visitor
    {
        public int VisitorId { get; set; }
        public string Name { get; set; }
        public GenderType Gender { get; set; }
        public string Mobile { get; set; }
        public string PersonWantToVisit { get; set; }
        public string PerposeOfVisit { get; set; }
        public int NoOfPersonWith { get; set; }
        public DateTime DateTimeIn { get; set; }
        public DateTime? DateTimeOut { get; set; }
        public int IssuedBy { get; set; }

    }
}
