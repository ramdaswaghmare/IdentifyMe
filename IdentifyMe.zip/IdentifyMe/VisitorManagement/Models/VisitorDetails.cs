﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VisitorManagement.Models
{
    public class VisitorDetails
    {
        public Visitor Visitor { get; set; }
        public IDProofDetails IDProofDetails { get; set; }
        public VehicleDetails VehicleDetails { get; set; }
    }
}
