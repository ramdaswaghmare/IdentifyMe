﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using SQL;
namespace VisitorManagement
{
    public class VisitorManagementService
    {
        public IDatabaseService db = new DatabaseService();
        public void AddVisitor(Models.VisitorDetails visitorDetails)
        {
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@Name",SqlDbType.NVarChar),
                new SqlParameter("@Gender",SqlDbType.NVarChar),
                new SqlParameter("@Mob",SqlDbType.NVarChar),
                new SqlParameter("@PersonWantToVisit",SqlDbType.NVarChar),
                new SqlParameter("@PerposeOfVisit",SqlDbType.NVarChar),
                new SqlParameter("@NoOfPersonsWith",SqlDbType.NVarChar),
                new SqlParameter("@DateTimeIn",SqlDbType.DateTime),
                new SqlParameter("@DateTimeOut",SqlDbType.DateTime),
                new SqlParameter("@IssuedBy",SqlDbType.Int),
                new SqlParameter("@IdentityProofTypeId",SqlDbType.Int),
                new SqlParameter("@IdProofNumber",SqlDbType.NVarChar),
                new SqlParameter("@VehicleName",SqlDbType.NVarChar),
                new SqlParameter("@VehicleNo",SqlDbType.NVarChar),
            };

            parameters[0].Value = visitorDetails.Visitor.Name;
            parameters[1].Value = visitorDetails.Visitor.Gender;
            parameters[2].Value = visitorDetails.Visitor.Mobile;
            parameters[3].Value = visitorDetails.Visitor.PersonWantToVisit;
            parameters[4].Value = visitorDetails.Visitor.PerposeOfVisit;
            parameters[5].Value = visitorDetails.Visitor.NoOfPersonWith;
            parameters[6].Value = visitorDetails.Visitor.DateTimeIn;
            parameters[7].Value = visitorDetails.Visitor.DateTimeOut; 
            parameters[8].Value = visitorDetails.Visitor.IssuedBy;

            parameters[9].Value = visitorDetails.IDProofDetails.IdentityProofTypeId;
            parameters[10].Value = visitorDetails.IDProofDetails.IdProofNumber;

            parameters[11].Value = visitorDetails.Visitor.VehicleName;
            parameters[12].Value = visitorDetails.Visitor.VehicleNo;

            db.ExecuteNonQuery("AddVisitor", parameters);
        }
    }
}
